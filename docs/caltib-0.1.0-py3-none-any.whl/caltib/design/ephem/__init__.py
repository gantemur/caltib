"""Ephemeris-based design tools.

Requires optional dependencies:
  pip install "caltib[ephemeris]"
"""