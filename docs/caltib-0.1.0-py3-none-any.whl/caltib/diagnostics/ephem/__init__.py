"""Ephemeris-based diagnostics.

Requires optional dependencies:
  pip install "caltib[ephemeris]"
"""