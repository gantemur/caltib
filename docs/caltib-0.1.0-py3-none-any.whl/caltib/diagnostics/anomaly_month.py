#!/usr/bin/env python3
from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, List, Optional

from caltib.api import get_calendar


def need_numpy():
    try:
        import numpy as np
        return np
    except ImportError as e:
        raise RuntimeError('Need numpy. Install: pip install "caltib[tools]"') from e


def need_matplotlib():
    try:
        import matplotlib.pyplot as plt
        return plt
    except ImportError as e:
        raise RuntimeError('Need matplotlib. Install: pip install "caltib[tools]"') from e


def parse_engine_list(s: str) -> List[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


@dataclass(frozen=True)
class SeriesData:
    label: str
    x_vals: "np.ndarray"
    y_vals: "np.ndarray"


def detrended_anomaly(np, x_vals: "np.ndarray", y_vals: "np.ndarray") -> "np.ndarray":
    """Subtracts the best linear fit and centers at zero."""
    coeffs = np.polyfit(x_vals, y_vals, 1)
    mean_line = np.polyval(coeffs, x_vals)
    anom = y_vals - mean_line
    return anom - float(np.mean(anom))


# =====================================================================
# FORWARD KINEMATICS: Time (t) -> Elongation Anomaly (Degrees)
# =====================================================================

def forward_series(np, engine: str, jd_start: float, jd_end: float, step_days: float) -> Optional[SeriesData]:
    eng = get_calendar(engine)
    if not hasattr(eng, "month") or not hasattr(eng.month, "true_elong_tt"):
        return None
        
    ts = np.arange(jd_start, jd_end + 1e-12, step_days, dtype=float)
    angles = []
    
    for jd in ts:
        t2000 = Fraction(jd) - Fraction(2451545)
        true_e = float(eng.month.true_elong_tt(t2000))
        mean_e = float(eng.month.mean_elong_tt(t2000))
        angles.append((true_e - mean_e) * 360.0)
        
    if not angles: return None
    
    a_arr = np.array(angles, dtype=float)
    a_arr -= float(np.mean(a_arr)) # Zero center
    return SeriesData(engine, ts, a_arr)


def reference_forward(np, jd_start: float, jd_end: float, step_days: float) -> SeriesData:
    from caltib.reference.solar import solar_longitude
    from caltib.reference.lunar import lunar_position
    
    ts = np.arange(jd_start, jd_end + 1e-12, step_days, dtype=float)
    angles = []
    
    for jd in ts:
        s = solar_longitude(jd)
        m = lunar_position(jd)
        e = (m.L_true_deg - s.L_true_deg) % 360.0
        angles.append(e)
        
    a_arr = np.array(angles, dtype=float)
    ang_rad = np.radians(a_arr)
    ang_unw = np.degrees(np.unwrap(ang_rad))
    anom = detrended_anomaly(np, ts, ang_unw)
    return SeriesData("Reference", ts, anom)


# =====================================================================
# INVERSE KINEMATICS: Fractional Lunation (l) -> Time Anomaly (Days)
# =====================================================================

def inverse_series(np, engine: str, jd_start: float, jd_end: float, step_days: float) -> Optional[SeriesData]:
    eng = get_calendar(engine)
    if not hasattr(eng, "month") or not hasattr(eng.month, "true_date"):
        return None
        
    t2000_start = Fraction(jd_start) - Fraction(2451545)
    t2000_end = Fraction(jd_end) - Fraction(2451545)
    
    # Establish fractional bounds
    l_start = float(eng.month.mean_elong_tt(t2000_start))
    l_end = float(eng.month.mean_elong_tt(t2000_end))
    
    # Step by fractional lunation
    step_l = step_days / 29.530588
    ls = np.arange(l_start, l_end + 1e-12, step_l, dtype=float)
    
    times = []
    anoms = []
    
    for l in ls:
        l_frac = Fraction(l)
        true_t = float(eng.month.true_date(l_frac))
        mean_t = float(eng.month.mean_date(l_frac))
        
        times.append(true_t + 2451545.0)
        anoms.append(true_t - mean_t) # Native analytical anomaly
        
    if not times: return None
    
    t_arr = np.array(times, dtype=float)
    a_arr = np.array(anoms, dtype=float)
    a_arr -= float(np.mean(a_arr)) # Zero center
    return SeriesData(engine, t_arr, a_arr)


def reference_inverse(np, jd_start: float, jd_end: float, step_days: float) -> SeriesData:
    from caltib.reference.solar import solar_longitude
    from caltib.reference.lunar import lunar_position
    
    def get_elong(jd: float) -> float:
        s = solar_longitude(jd)
        m = lunar_position(jd)
        return (m.L_true_deg - s.L_true_deg) % 360.0

    eng = get_calendar("phugpa") 
    t2000_start = Fraction(jd_start) - Fraction(2451545)
    t2000_end = Fraction(jd_end) - Fraction(2451545)
    
    l_start = float(eng.month.mean_elong_tt(t2000_start))
    l_end = float(eng.month.mean_elong_tt(t2000_end))
    
    step_l = step_days / 29.530588
    ls = np.arange(l_start, l_end + 1e-12, step_l, dtype=float)
    
    times = []
    jd_0 = 2451550.09766 # Approximate J2000 new moon baseline
    
    for l in ls:
        target_deg = (l * 360.0) % 360.0
        jd_guess = jd_0 + l * 29.530588
        
        # Iteratively solve for continuous arbitrary fractional lunations
        jd_exact = jd_guess
        for _ in range(6):
            e = get_elong(jd_exact)
            diff = e - target_deg
            if diff > 180: diff -= 360
            if diff < -180: diff += 360
            if abs(diff) < 1e-6:
                break
            jd_exact -= diff / 12.190749
            
        times.append(jd_exact)
        
    t_arr = np.array(times, dtype=float)
    n_arr = np.array(ls, dtype=float)
    anom = detrended_anomaly(np, n_arr, t_arr)
    
    return SeriesData("Reference", t_arr, anom)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Continuous Month Engine Anomaly vs Truth Ephemeris.")
    p.add_argument("--mode", choices=("forward", "inverse"), default="inverse",
                   help="forward: JD->Elongation (degrees). inverse: Lunation->JD (days).")
    p.add_argument("--engines", default="l4",
                   help="Comma list of reform engines to plot.")
    p.add_argument("--jd-start", type=float, default=None, help="Start JD (TT-like) as float.")
    p.add_argument("--jd-end", type=float, default=None, help="End JD (TT-like) as float.")
    p.add_argument("--center-jd", type=float, default=2461072.5, help="Center JD if start/end not given.")
    p.add_argument("--window", type=float, default=200.0, help="Half-window in days.")
    p.add_argument("--step", type=float, default=0.25, help="Sampling step in days.")
    p.add_argument("--out", default="anomaly_month_continuous.png", help="Output PNG filename.")
    args = p.parse_args(argv)

    np = need_numpy()
    plt = need_matplotlib()

    if (args.jd_start is None) != (args.jd_end is None):
        raise SystemExit("Provide both --jd-start and --jd-end, or neither.")

    if args.jd_start is None:
        jd_start = float(args.center_jd) - float(args.window)
        jd_end = float(args.center_jd) + float(args.window)
    else:
        jd_start = float(args.jd_start)
        jd_end = float(args.jd_end)

    if jd_end <= jd_start:
        raise SystemExit("--jd-end must be > --jd-start")

    engines = parse_engine_list(args.engines)

    print(f"Interval JD: [{jd_start:.3f}, {jd_end:.3f}]")
    print(f"Mode: {args.mode.upper()}")
    print(f"Engines: {engines}")

    series: List[SeriesData] = []

    # Run Engine Proxy Series
    for eng in engines:
        try:
            if args.mode == "forward":
                s = forward_series(np, eng, jd_start, jd_end, float(args.step))
            else:
                s = inverse_series(np, eng, jd_start, jd_end, float(args.step))
                
            if s is None:
                print(f"  {eng}: Missing month engine functions or no samples")
            else:
                print(f"  {eng}: {len(s.x_vals)} continuous samples evaluated")
                series.append(s)
        except Exception as e:
            print(f"  {eng}: ERROR: {e}")

    # Run Truth Ephemeris Series
    try:
        if args.mode == "forward":
            s_truth = reference_forward(np, jd_start, jd_end, float(args.step))
        else:
            s_truth = reference_inverse(np, jd_start, jd_end, float(args.step))
            
        print(f"  Reference: {len(s_truth.x_vals)} continuous samples evaluated")
        series.append(s_truth)
    except Exception as e:
        print(f"  Reference ERROR: {e}")

    # Plot
    center = 0.5 * (jd_start + jd_end)
    
    colors: Dict[str, str] = {
        "l1": "tab:pink", "l2": "tab:cyan", "l3": "tab:olive", "l4": "gold",
        "Reference": "black"
    }

    plt.figure(figsize=(12, 5))

    for s in series:
        x_rel = s.x_vals - center
        c = colors.get(s.label, "tab:blue")
        if s.label == "Reference":
            plt.plot(x_rel, s.y_vals, linestyle="--", color=c, linewidth=1.5, alpha=0.9, label="Reference (ELP2000)")
        else:
            plt.plot(x_rel, s.y_vals, linestyle="-", color=c, linewidth=1.2, alpha=0.8, label=s.label)

    if args.mode == "forward":
        plt.title("Continuous Month Engine Anomaly: (True - Mean Elongation)")
        plt.ylabel("Anomaly (Degrees)")
    else:
        plt.title("Continuous Month Engine Anomaly: (True - Mean Time of Lunation)")
        plt.ylabel("Time Anomaly (Days)")
        
    plt.xlabel("Days relative to interval center")
    plt.grid(True, alpha=0.3)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(args.out, dpi=180)
    print(f"Saved: {args.out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())